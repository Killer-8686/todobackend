create view task_category_inner(id, task_date, task, category) as
SELECT t.id,
       t.task_date,
       t.title AS task,
       c.title AS category
FROM todolist.task t
         JOIN todolist.category c ON t.category_id = c.id;

alter table task_category_inner
    owner to postgres;

