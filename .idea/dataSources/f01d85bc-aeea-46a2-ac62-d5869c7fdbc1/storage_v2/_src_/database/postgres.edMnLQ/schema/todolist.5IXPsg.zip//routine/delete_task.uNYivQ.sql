create function delete_task() returns trigger
    language plpgsql
as
$$
BEGIN
	/* можно было упаковать все условия в один if-else, но тогда он становится не очень читабельным */

    /*  категория НЕПУСТАЯ                 и        статус задачи ЗАВЕРШЕН */
    if (coalesce(old.category_id, 0)>0       and       coalesce(old.completed, 0)=1) then
		update todolist.category set completed_count = (coalesce(completed_count, 0)-1) where id = old.category_id and user_id=old.user_id;
	end if;
    
	/*  категория НЕПУСТАЯ                и         статус задачи НЕЗАВЕРШЕН */
    if (coalesce(old.category_id, 0)>0      and        coalesce(old.completed, 0)=0) then
		update todolist.category set uncompleted_count = (coalesce(uncompleted_count, 0)-1) where id = old.category_id and user_id=old.user_id;
	end if;
	
	
	 /* общая статистика */
	if coalesce(old.completed, 0)=1 then
		update todolist.stat set completed_total = (coalesce(completed_total, 0)-1)  where user_id=old.user_id;
	else
		update todolist.stat set uncompleted_total = (coalesce(uncompleted_total, 0)-1)  where user_id=old.user_id;
    end if;
    

	RETURN OLD;
    
END
$$;

alter function delete_task() owner to postgres;

