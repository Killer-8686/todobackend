create materialized view mat_view as
SELECT t.id,
       t.task_date,
       t.title AS task,
       c.title AS category
FROM todolist.task t
         JOIN todolist.category c ON t.category_id = c.id;

alter materialized view mat_view owner to postgres;

