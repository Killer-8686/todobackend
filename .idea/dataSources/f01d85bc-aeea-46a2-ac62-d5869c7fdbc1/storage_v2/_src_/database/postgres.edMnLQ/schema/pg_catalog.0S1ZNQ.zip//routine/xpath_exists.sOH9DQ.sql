create function xpath_exists(text, xml) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function xpath_exists(text, xml, text[]) is 'test XML value against XPath expression';

alter function xpath_exists(text, xml, text[]) owner to postgres;

